#include<iostream>
using namespace std;
int main()
{
   float marks;
   cout<<"Enter the markes between (0-100):";
   cin>>marks;
  
   if(marks>=90)
    {
    	cout<<"Your grade is :A";
	}
  	 if(marks>=80)
    {
    	cout<<"Your grade is :B";
	}
  	 if(marks>=70)
    {
    	cout<<"Your grade is :C";
	}
	 if(marks<70)
    {
    	cout<<"Your grade is :D";
	}
	   return 0;	
}
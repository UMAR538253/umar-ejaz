#include<iostream>
using namespace std;
int main()
{
	char cha;
	cout<<"Enter a single character U MS lory:)";
	cin>>cha;
   	if(cha>='0'&& cha<='9')
	{
	cout<<"A Digit Charecter. ";
	}
	 else if(cha>='A'&& cha<='Z')
	{
	cout<<"A Uppercase Charecter. ";
	}
      else	if(cha>='a'&& cha<='z')
	{
	cout<<"A lowercase Charecter. ";
	}
	  else	
	{
	cout<<"A  Special Character.";
	}
	cout<<"G o Bawa G Dee";
 return 0;	
}
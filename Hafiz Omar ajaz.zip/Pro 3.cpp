#include<iostream>
using namespace std;
int main()
{

 int num1;
 int num2;
 int result;
 cout<<"Enter your first number";
 cin>>num1;
 cout<<"Enter your Secend number";
 cin>>num2;
 result=num1+num2;
 cout<<result; 
	
	
}
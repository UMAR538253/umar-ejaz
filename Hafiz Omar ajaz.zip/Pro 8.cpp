#include<iostream>
using namespace std;
int main()
{
	int year;
	cout<<"Enter any Year :";
	cin>>year;
	if ((year%4==0 && year%100!=0)||(year%400==0))
	{
	cout<<year<<"  leap year"<<endl;
	}
	else
	cout<<year<<" not leap year"<<endl;
	return 0;
}
#include<iostream>
using namespace std;
int main()
{ double radius;
  float area;
  cout<<"Enter the circle Radius"<<endl;
  cin>>radius;
  area=3.14*radius*radius;
  cout<<area;
	
	
	
	
	
}



